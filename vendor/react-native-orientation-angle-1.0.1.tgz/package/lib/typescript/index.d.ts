import type { IOrientationAngle } from './types';
declare const orientationAngle: IOrientationAngle;
export { orientationAngle };
