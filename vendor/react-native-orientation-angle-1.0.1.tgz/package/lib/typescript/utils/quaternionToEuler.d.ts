import type { EventData } from '../types';
export declare const quaternionToEuler: (data: EventData) => {
    pitch: number;
    roll: number;
    yaw: number;
};
